# Changelog

## 1.0.12

- Verify the current source on DSH v0.2.0-rc.2: Web settings load and persist, authenticated ComfyUI image reads succeed, and unauthenticated reads are rejected; the plugin-facing APIs used here are unchanged from v0.1.7-rc.2.
- Replace the removed `settingsScope` client service with live `Config` fields and `configForms`, fixing plugins stuck pending on DSH v0.1.7 and v0.2.0.
- Preserve remote read-only media preferences through the authenticated RPC channel.
- Register media endpoints on DSH's authenticated `/api` bridge; real v0.1.7 testing caught the old custom channel returning HTTP 405.
- Render the turn-tail media card from the slot's actual turn props; verified image display and enlargement in the v0.1.7-rc.2 Web UI.
- Align the profile entry id with the old `inline-media` settings section for migration.

## 1.0.11

- Register the authenticated RPC route inside a connection-injected context so
  Cordis can provide the Web server dependency during deferred setup.
- Verify host startup, the settings section, and HTTP health on DSH v0.1.5-rc.1.

## 1.0.10

- Promote 1.0.10-alpha.1 to the stable release without runtime changes.
- Verify plugin import and host startup on DSH v0.1.2-rc.1; retain the v0.1.3-alpha.1 API adaptation.
- Browser media playback and the final DSH v0.1.3 release have not been verified.

## 1.0.10-alpha.1

- Adapt to DSH v0.1.3-alpha.1: register host settings through `settings.register`,
  register client projections through `uiConversation.events`, and use the
  authenticated two-argument RPC registration contract.
- Remove the unused settings package peer dependency; consume the host-provided
  settings service and add a real-dependency host registration check.

## 1.0.9

- Collect media paths from tool-call arguments as well as the assistant's final
  text, so every image read during a turn remains available in its preview.

## 1.0.8 (deprecated)

- Preserve output-directory context across assistant steps in one turn, so a
  later final answer containing only media filenames still renders previews.
- Superseded by 1.0.9 because tool-call-only media references were not retained.

## 1.0.7 (deprecated)

- Resolve backticked media filenames against a preceding backticked directory,
  matching the common "output directory plus file list" response format.
- Superseded by 1.0.9 because it only inspected assistant text.

## 1.0.6

- Resolve workspace media from persisted session metadata when a historical
  conversation is no longer attached to a live host session.

## 1.0.5

- Register the browser bundle under the scoped package name expected by the
  DSH module loader.

## 1.0.4

- Read media candidates from the standard assistant-step projection so the
  first inline preview renders reliably.
- Avoid extracting duplicate paths from Markdown links, code spans, and URLs.

## 1.0.3

- Clarify and enforce the transport split: workspace files use the DSH host,
  regular HTTP(S) media loads directly, and only recognized ComfyUI URLs use
  the optional proxy.
- Mark ComfyUI as optional throughout the bilingual settings UI and README.

## 1.0.2

- Make the settings navigation and all setting copy react live to DSH's
  English/Chinese UI language through the standard locale slot contract.
- Add a dependency-free client registration test for both locale dictionaries
  and the settings locale namespace.

## 1.0.1

- Publish the plugin as `@wisdoverse/dsh-inline-media-viewer` for one-command
  installation through the DSH plugin manager.
- Align the bundle manifest, package metadata, and bilingual installation
  documentation with the scoped package name.

## 1.0.0

- **Initial public release.** Inline image/video/audio previews in the
  conversation tail (`conversation.chat.turnTail` projection): any media
  path or media URL mentioned in a chat turn renders inline under that
  turn.
- **Workspace-confined local reads** — a path renders only when it
  resolves inside the calling session's workspace root (`realpath` +
  containment; no symlink escapes).
- **Configurable ComfyUI proxy** — media URLs on the local aliases
  (`127.0.0.1`/`localhost` on port 8188) or on the configured server
  address are fetched server-side from the configured origin, with
  redirects refused, a 20 s timeout, and a 48 MiB cap.
- **Settings page** (媒体预览 / Media preview): auto-render toggle,
  per-turn cap (1–30), max media height (160–1200 px), ComfyUI server
  address — persisted through the DSH settings document (loopback
  writes).
- **Pure helpers** in a dependency-free `lib.js` with a zero-dependency
  unit test runner (`node test.mjs`), plus README, SECURITY, and MIT
  LICENSE.
